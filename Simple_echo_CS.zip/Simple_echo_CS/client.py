import socket
from getpass import getpass

sock = socket.socket()
sock.setblocking(1)
ip = getpass("Input IP: ")
port = int(getpass("Port: "))

sock.connect(('localhost', port))

msg = ""

while msg != "exit":
	data = sock.recv(1024)
	print("Feedback from Server: ", data.decode())
	if str(data.decode()) == "Create password:":
		msg = getpass("Message to Server: ")
	else:
		msg = input("Message to Server: ")
	sock.send(msg.encode())

print("Disconnecting...")
sock.close()
