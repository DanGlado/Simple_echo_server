import socket
import logging
import pickle
from getpass import getpass

sock = socket.socket(socket.SOCK_DGRAM)
port = int(getpass("Port №: "))

while True:
	try:
		sock.bind(('', port))
	except PermissionError:
		port+=1
		continue
	except OSError:
		port+=1
		continue
	break


print(f"Port bind: {port}")
sock.listen(2)
logging.basicConfig(filename='logs.log', filemode='w', format='%(message)s', level=logging.INFO)
msg = ''

print("Server start")

users = dict()
clients_pass = dict()
passwd_file = 'passwd_file'

while True:
	conn, addr = sock.accept()
	if addr[0] not in users.keys():
		conn.send("Please, input your name ".encode())
		data = conn.recv(1024)
		name = data.decode()
		users.update({addr[0]: name})
		
		conn.send(f"Create password:".encode())
		data = conn.recv(1024)
		passwd = str(data.decode())

		with open(passwd_file, 'wb') as file:
			pickle.dump(clients_pass, file)
		clients_pass.update({addr[0]: passwd})
		print(clients_pass)

		conn.send(f"Hello, new user {users[addr[0]]}".encode())
	
	else:
		conn.send(f"Hello, {users[addr[0]]}".encode())

	# Password




	print(users)
	logging.info(f"Connected: {addr}, {name}")
	msg = ""
	while msg != 'exit':
		data = conn.recv(1024)
		if not data:
			break
		msg = str(data.decode())
		conn.send(data.upper())
		print(data.decode())

conn.close()
	